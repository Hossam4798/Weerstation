#include "mainwindow.h"

// hier wordt de de connectie met de database opgezet

void MainWindow::dbConnect(){

    //Main database
    dbOne = QSqlDatabase::addDatabase("QMYSQL", "first");
    dbOne.setHostName("databases.aii.avans.nl");
    dbOne.setPort(3306);
    dbOne.setUserName("qjpmdint");
    dbOne.setPassword("Ab12345");
    dbOne.setDatabaseName("qjpmdint_db");

    //Back-up database
    dbTwo = QSqlDatabase::addDatabase("QMYSQL", "second");
    dbTwo.setHostName("databases.aii.avans.nl");
    dbTwo.setPort(3306);
    dbTwo.setUserName("hsahosma");
    dbTwo.setPassword("Ab12345");
    dbTwo.setDatabaseName("hsahosma_db");

        if(dbOne.open()){

            db0 = dbOne;

        }else if(dbTwo.open()){
             QMessageBox::information(this, "Failed", "Database connection Failed. Starting local database.");
             db0 = dbTwo;
        }
    else{
        QMessageBox::information(this, "Failed", "Couldn't open any database. Click ok to close application");
    }

}
