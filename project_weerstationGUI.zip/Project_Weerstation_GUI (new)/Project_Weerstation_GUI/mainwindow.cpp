#include "mainwindow.h"
#include "ui_mainwindow.h"


QT_CHARTS_USE_NAMESPACE

// constructor
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    // init
    ui->setupUi(this);
    dbConnect();
    current_meer_info = 0;
    fill_Grid();


    // timer voor een update elke minuut
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(fill_Grid()));
    timer->start(30000);
}


// maakt de temperatuur grafiek
QtCharts::QChartView *MainWindow::make_temp_chart(){
    QLineSeries *series = new QLineSeries();// serie data temperatuur

    series->append(1,getValue(1,4));
    series->append(2,getValue(1,3));
    series->append(3,getValue(1,2));
    series->append(4,getValue(1,1));
    series->append(5,getValue(1,0));

    QChart * chart = new QChart;
    chart->legend()->hide();
    chart->addSeries(series);
    chart->createDefaultAxes();
    chart->setTitle("temperatuur");

    QValueAxis *axisY = new QValueAxis;
    axisY->setMax(80);
    axisY->setMin(-10);
    axisY->setTickCount(10);


    temp_chart = new QChartView(chart);
    temp_chart->chart()->setAxisY(axisY, series);
    return temp_chart;
}

// maakt de luchtvochtigheid grafiek
QtCharts::QChartView *MainWindow::make_humid_chart(){
    QLineSeries *series2 = new QLineSeries();// serie data luchtvochtigheid


    series2->append(1,getValue(2,4));
    series2->append(2,getValue(2,3));
    series2->append(3,getValue(2,2));
    series2->append(4,getValue(2,1));
    series2->append(5,getValue(2,0));

    QChart *chart2 = new QChart();
    chart2 ->legend()->hide();
    chart2->addSeries(series2);
    chart2->createDefaultAxes();
    chart2->setTitle("luchtvochtigheid");

    QValueAxis *axisY = new QValueAxis;
    axisY->setMax(100);
    axisY->setMin(0);
    axisY->setTickCount(11);


    humid_chart = new QChartView(chart2);
    humid_chart->chart()->setAxisY(axisY, series2);
    return humid_chart;
}

// maakt de lux grafiek
QtCharts::QChartView *MainWindow::make_lux_chart(){
    QLineSeries *series3 = new QLineSeries();// serie data licht

    series3->append(1,getValue(3,4));
    series3->append(2,getValue(3,3));
    series3->append(3,getValue(3,2));
    series3->append(4,getValue(3,1));
    series3->append(5,getValue(3,0));

    QChart *chart3 = new QChart();
    chart3 ->legend()->hide();
    chart3->addSeries(series3);
    chart3->createDefaultAxes();
    chart3->setTitle("lux");

    QValueAxis *axisY = new QValueAxis;
    axisY->setMax(5000);
    axisY->setMin(0);
    axisY->setTickCount(11);

    lux_chart = new QChartView(chart3);
    lux_chart->chart()->setAxisY(axisY, series3);
    return lux_chart;
}

// deze functie wordt elke minuut aangeroepen en hier worden de grafieken en tabellen geupdate;
void MainWindow::fill_Grid(){

    make_temp_chart();
    make_humid_chart();
    make_lux_chart();

    if (current_meer_info == 0){
    }
    else if (current_meer_info == 1){
        on_pushButton_clicked();
    }
    else if (current_meer_info == 2){
        on_pushButton_2_clicked();
    }
    else if (current_meer_info == 3){
        on_toolButton_clicked();
    }

    ui->gridLayout->addWidget(temp_chart,0,0);
    ui->gridLayout->addWidget(humid_chart,1,0);
    ui->gridLayout->addWidget(lux_chart,2,0);
}


// maakt en laat de tabel met de historische data zien (temperatuur)
void MainWindow::on_pushButton_clicked()
{
    current_meer_info = 1;

    QSqlQuery query("SELECT reading_time, value1 FROM sensordata ORDER BY id desc limit 20",db0);
    ui->tableWidget->setColumnCount(2);
    ui->tableWidget->setRowCount(query.size());
    ui->tableWidget->setHorizontalHeaderLabels(QString("tijd; temperatuur").split(";"));
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

int i = 0;
    while (query.next()){

        ui->tableWidget->setItem(i,0,new QTableWidgetItem(query.value(0).toString()));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(query.value(1).toString()));
        ui->tableWidget->resizeColumnToContents(0);
        i++;
}
}

// maakt en laat de tabel met de historische data zien (luchtvochtigheid
void MainWindow::on_pushButton_2_clicked()
{

    current_meer_info = 2;

    QSqlQuery query("SELECT reading_time, value2 FROM sensordata ORDER BY id desc limit 20",db0);
    ui->tableWidget->setColumnCount(2);
    ui->tableWidget->setRowCount(query.size());
    ui->tableWidget->setHorizontalHeaderLabels(QString("tijd; luchtvochtigheid").split(";"));
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

int i = 0;
    while (query.next()){

        ui->tableWidget->setItem(i,0,new QTableWidgetItem(query.value(0).toString()));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(query.value(1).toString()));
        ui->tableWidget->resizeColumnToContents(0);
        i++;
}
}

// maakt en laat de tabel met de historische data zien (lux)
void MainWindow::on_toolButton_clicked()
{
    current_meer_info = 3;

    QSqlQuery query("SELECT reading_time, value3 FROM sensordata ORDER BY id desc limit 20",db0);
    ui->tableWidget->setColumnCount(2);
    ui->tableWidget->setRowCount(query.size());
    ui->tableWidget->setHorizontalHeaderLabels(QString("tijd; lux").split(";"));
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

int i = 0;
    while (query.next()){

        ui->tableWidget->setItem(i,0,new QTableWidgetItem(query.value(0).toString()));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(query.value(1).toString()));
        ui->tableWidget->resizeColumnToContents(0);
        i++;
}
}

// dit haalt de laatste 5 punten uit de database voor alle 3 de waardes.
int MainWindow::getValue(int type, int value){
    int temp = 0;
    int humidity = 0;
    int lux = 0;

    // als je de temperatuur wil
    if (type == 1){
        QSqlQuery query("SELECT value1 FROM sensordata WHERE id = (SELECT max(id - ?) FROM sensordata) ORDER BY reading_time desc limit 5",db0);
        query.addBindValue(value);
        query.exec();

        while(query.next()){
            temp = query.value(0).toInt();
            qWarning() << temp;
        }
        return temp;
}
    //als je de luchtvochtigheid wil
    else if (type == 2){
        QSqlQuery query("SELECT value2 FROM sensordata WHERE id = (SELECT max(id - ?) FROM sensordata) ORDER BY id desc", db0);
        query.addBindValue(value);
        query.exec();

        while(query.next()){
            humidity = query.value(0).toInt();
            qWarning() << humidity;
        }
    return humidity;
}
    // als je de lux wil
   else if (type == 3){
        QSqlQuery query("SELECT value3 FROM sensordata WHERE id = (SELECT max(id - ?) FROM sensordata) ORDER BY id desc", db0);
        query.addBindValue(value);
        query.exec();

        while(query.next()){
            lux = query.value(0).toInt();
            qWarning() << lux;
        }
    return lux;
}
}

// destructor
MainWindow::~MainWindow()
{
    dbOne.close();
    dbTwo.close();
    delete ui;
}


