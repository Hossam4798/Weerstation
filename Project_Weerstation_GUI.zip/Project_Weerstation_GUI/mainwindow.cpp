#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QApplication>
#include <QtWidgets/QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>

QT_CHARTS_USE_NAMESPACE

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}



void MainWindow::on_pushButton_clicked()
{
    QLineSeries *series = new QLineSeries();// serie data temperatuur

    series->append(0,6);
    series->append(2,4);
    series->append(3,8);
    series->append(7,4);
    series->append(10,5);

    QChart *chart = new QChart();
    chart ->legend()->hide();
    chart->addSeries(series);
    chart->createDefaultAxes();
    chart->setTitle("Weerstation gegevens temperatuur");

    QChartView *chartView = new QChartView(chart);
    chartView -> setRenderHint(QPainter::Antialiasing);

    window.setCentralWidget(chartView);
    window.resize(400, 300);
    window.show();

}



void MainWindow::on_pushButton_2_clicked()
{
    QLineSeries *series2 = new QLineSeries();// serie data luchtvochtigheid

    series2->append(2,4);
    series2->append(3,8);
    series2->append(4,9);
    series2->append(7,4);
    series2->append(10,5);

    QChart *chart2 = new QChart();
    chart2 ->legend()->hide();
    chart2->addSeries(series2);
    chart2->createDefaultAxes();
    chart2->setTitle("Weerstation gegevens luchtvochtigheid");

    QChartView *chartView2 = new QChartView(chart2);
    chartView2 -> setRenderHint(QPainter::Antialiasing);

    window.setCentralWidget(chartView2);
    window.resize(400, 300);
    window.show();


}

void MainWindow::on_toolButton_clicked()
{
    QLineSeries *series3 = new QLineSeries();// serie data licht

    series3->append(4,1);
    series3->append(5,8);
    series3->append(6,9);
    series3->append(8,5);
    series3->append(10,5);

    QChart *chart3 = new QChart();
    chart3 ->legend()->hide();
    chart3->addSeries(series3);
    chart3->createDefaultAxes();
    chart3->setTitle("Weerstation gegevens luchtvochtigheid");

    QChartView *chartView2 = new QChartView(chart3);
    chartView2 -> setRenderHint(QPainter::Antialiasing);

    window.setCentralWidget(chartView2);
    window.resize(400, 300);
    window.show();

}

MainWindow::~MainWindow()
{
    delete ui;
}


