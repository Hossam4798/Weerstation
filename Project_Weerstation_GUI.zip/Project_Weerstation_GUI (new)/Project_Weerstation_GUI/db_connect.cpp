#include "mainwindow.h"

// hier wordt de de connectie met de database opgezet

void MainWindow::dbConnect(){

    //Online database
    dbOne = QSqlDatabase::addDatabase("QMYSQL", "first");
    dbOne.setHostName("databases.aii.avans.nl");
    dbOne.setPort(3306);
    dbOne.setUserName("qjpmdint");
    dbOne.setPassword("Ab123456");
    dbOne.setDatabaseName("qjpmdint_db");

    //Local database
    dbTwo = QSqlDatabase::addDatabase("QMYSQL", "second");
    dbTwo.setHostName("localhost");
    dbTwo.setPort(3306);
    dbTwo.setUserName("root");
    dbTwo.setPassword("");
    dbTwo.setDatabaseName("weerstation");

        if(dbOne.open()){

            db0 = dbOne;

        }else if(dbTwo.open()){
             QMessageBox::information(this, "Failed", "Database connection Failed. Starting local database.");
             db0 = dbTwo;
        }
    else{
        QMessageBox::information(this, "Failed", "Couldn't open any database. Click ok to close application");
    }

}
