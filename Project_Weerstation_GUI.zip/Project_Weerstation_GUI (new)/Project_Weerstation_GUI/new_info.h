#ifndef NEW_INFO_H
#define NEW_INFO_H

#include <QWidget>

namespace Ui {
class new_info;
}

class new_info : public QWidget
{
    Q_OBJECT

public:
    explicit new_info(QWidget *parent = nullptr);
    ~new_info();

private:
    Ui::new_info *ui;
};

#endif // NEW_INFO_H
