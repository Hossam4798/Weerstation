#include "new_info.h"
#include "mainwindow.h"
#include "ui_new_info.h"

new_info::new_info(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::new_info)
{
    ui->setupUi(this);
}

new_info::~new_info()
{
    delete ui;
}
