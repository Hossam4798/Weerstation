
#include "mainwindow.h"



QT_CHARTS_USE_NAMESPACE

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow data;
    data.show();

    return a.exec();
}
