/********************************************************************************
** Form generated from reading UI file 'new_info.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEW_INFO_H
#define UI_NEW_INFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_new_info
{
public:
    QTableWidget *tableWidget;

    void setupUi(QWidget *new_info)
    {
        if (new_info->objectName().isEmpty())
            new_info->setObjectName(QString::fromUtf8("new_info"));
        new_info->resize(744, 357);
        tableWidget = new QTableWidget(new_info);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(370, 20, 291, 251));

        retranslateUi(new_info);

        QMetaObject::connectSlotsByName(new_info);
    } // setupUi

    void retranslateUi(QWidget *new_info)
    {
        new_info->setWindowTitle(QApplication::translate("new_info", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class new_info: public Ui_new_info {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEW_INFO_H
