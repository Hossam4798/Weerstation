#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QApplication>
#include <QtWidgets/QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>

QT_CHARTS_USE_NAMESPACE


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    dbConnect();

}

void MainWindow::on_pushButton_clicked()
{
    QLineSeries *series = new QLineSeries();// serie data temperatuur

    series->append(0,getTemp(0));
    series->append(1,getTemp(1));
    series->append(2,getTemp(2));
    series->append(3,getTemp(3));
    series->append(4,getTemp(4));

    QChart *chart = new QChart();
    chart ->legend()->hide();
    chart->addSeries(series);
    chart->createDefaultAxes();
    chart->setTitle("Weerstation gegevens temperatuur");

    QChartView *chartView = new QChartView(chart);
    chartView -> setRenderHint(QPainter::Antialiasing);

    window.setCentralWidget(chartView);
    window.resize(400, 300);
    window.show();

}



void MainWindow::on_pushButton_2_clicked()
{
    QLineSeries *series2 = new QLineSeries();// serie data luchtvochtigheid

    series2->append(0,getHumid(0));
    series2->append(1,getHumid(1));
    series2->append(2,getHumid(2));
    series2->append(3,getHumid(3));
    series2->append(4,getHumid(4));

    QChart *chart2 = new QChart();
    chart2 ->legend()->hide();
    chart2->addSeries(series2);
    chart2->createDefaultAxes();
    chart2->setTitle("Weerstation gegevens luchtvochtigheid");

    QChartView *chartView2 = new QChartView(chart2);
    chartView2 -> setRenderHint(QPainter::Antialiasing);

    window.setCentralWidget(chartView2);
    window.resize(400, 300);
    window.show();


}

void MainWindow::on_toolButton_clicked()
{
    QLineSeries *series3 = new QLineSeries();// serie data licht

    series3->append(0,getLight(0));
    series3->append(1,getLight(1));
    series3->append(2,getLight(2));
    series3->append(3,getLight(3));
    series3->append(4,getLight(4));

    QChart *chart3 = new QChart();
    chart3 ->legend()->hide();
    chart3->addSeries(series3);
    chart3->createDefaultAxes();
    chart3->setTitle("Weerstation gegevens luchtvochtigheid");

    QChartView *chartView2 = new QChartView(chart3);
    chartView2 -> setRenderHint(QPainter::Antialiasing);

    window.setCentralWidget(chartView2);
    window.resize(400, 300);
    window.show();

}

int MainWindow::getTemp(int a){

    int temp = 0;

    if(a == 0){
        QSqlQuery query("SELECT value1 FROM sensordata WHERE id = (SELECT max(id) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            temp = query.value(0).toInt();
            qWarning() << temp;
        }
    }else if(a == 1){
        QSqlQuery query("SELECT value1 FROM sensordata WHERE id = (SELECT (max(id)-1) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            temp = query.value(0).toInt();
            qWarning() << temp;
        }
    }else if(a == 2){
        QSqlQuery query("SELECT value1 FROM sensordata WHERE id = (SELECT (max(id)-2) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            temp = query.value(0).toInt();
            qWarning() << temp;
        }
    }else if(a == 3){
        QSqlQuery query("SELECT value1 FROM sensordata WHERE id = (SELECT (max(id)-3) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            temp = query.value(0).toInt();
            qWarning() << temp;
        }
    }else if(a == 4){
        QSqlQuery query("SELECT value1 FROM sensordata WHERE id = (SELECT (max(id)-4) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            temp = query.value(0).toInt();
            qWarning() << temp;
        }
    }
    //switch case doen
    return temp;
}

int MainWindow::getHumid(int a){

    int humidity = 0;

    if(a == 0){
        QSqlQuery query("SELECT value2 FROM sensordata WHERE id = (SELECT max(id) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            humidity = query.value(0).toInt();
            qWarning() << humidity;
        }
    }else if(a == 1){
        QSqlQuery query("SELECT value2 FROM sensordata WHERE id = (SELECT (max(id)-1) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            humidity = query.value(0).toInt();
            qWarning() << humidity;
        }
    }else if(a == 2){
        QSqlQuery query("SELECT value2 FROM sensordata WHERE id = (SELECT (max(id)-2) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            humidity = query.value(0).toInt();
            qWarning() << humidity;
        }
    }else if(a == 3){
        QSqlQuery query("SELECT value2 FROM sensordata WHERE id = (SELECT (max(id)-3) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            humidity = query.value(0).toInt();
            qWarning() << humidity;
        }
    }else if(a == 4){
        QSqlQuery query("SELECT value2 FROM sensordata WHERE id = (SELECT (max(id)-4) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            humidity = query.value(0).toInt();
            qWarning() << humidity;
        }
    }
    //switch case doen
    return humidity;
}

int MainWindow::getLight(int a){

    int lux = 0;

    if(a == 0){
        QSqlQuery query("SELECT value3 FROM sensordata WHERE id = (SELECT max(id) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            lux = query.value(0).toInt();
            qWarning() << lux;
        }
    }else if(a == 1){
        QSqlQuery query("SELECT value3 FROM sensordata WHERE id = (SELECT (max(id)-1) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            lux = query.value(0).toInt();
            qWarning() << lux;
        }
    }else if(a == 2){
        QSqlQuery query("SELECT value3 FROM sensordata WHERE id = (SELECT (max(id)-2) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            lux = query.value(0).toInt();
            qWarning() << lux;
        }
    }else if(a == 3){
        QSqlQuery query("SELECT value3 FROM sensordata WHERE id = (SELECT (max(id)-3) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            lux = query.value(0).toInt();
            qWarning() << lux;
        }
    }else if(a == 4){
        QSqlQuery query("SELECT value3 FROM sensordata WHERE id = (SELECT (max(id)-4) FROM sensordata) ORDER BY id desc", db0);
        while(query.next()){
            lux = query.value(0).toInt();
            qWarning() << lux;
        }
    }
    //switch case doen
    return lux;
}

void MainWindow::dbConnect(){

    //Online database
    dbOne = QSqlDatabase::addDatabase("QMYSQL", "first");
    dbOne.setHostName("databases.aii.avans.nl");
    dbOne.setPort(3306);
    dbOne.setUserName("qjpmdint");
    dbOne.setPassword("Ab123465");
    dbOne.setDatabaseName("qjpmdint_db");

    //Local database
    dbTwo = QSqlDatabase::addDatabase("QMYSQL", "second");
    dbTwo.setHostName("localhost");
    dbTwo.setPort(3306);
    dbTwo.setUserName("root");
    dbTwo.setPassword("");
    dbTwo.setDatabaseName("weatherstation");

        if(dbOne.open()){

            db0 = dbOne;

        }else if(dbTwo.open()){
             QMessageBox::information(this, "Failed", "Database connection Failed. Starting local database.");
             db0 = dbTwo;
        }


    else{
        QMessageBox::information(this, "Failed", "Couldn't open any database. Click ok to close application");
    }

}

MainWindow::~MainWindow()
{
    dbOne.close();
    dbTwo.close();
    delete ui;
}


