#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QApplication>
#include <QtWidgets/QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QtSql>
#include <QSqlDatabase>
#include <QMessageBox>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    int getTemp(int a);
    int getHumid(int a);
    int getLight(int a);
    void dbConnect();
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

    void on_widget_customContextMenuRequested(const QPoint &pos);

    void on_pushButton_2_clicked();

    void on_toolButton_clicked();

private:
    Ui::MainWindow *ui;
    QMainWindow window;

    QSqlDatabase db0;
    QSqlDatabase dbOne;
    QSqlDatabase dbTwo;
};
#endif // MAINWINDOW_H
